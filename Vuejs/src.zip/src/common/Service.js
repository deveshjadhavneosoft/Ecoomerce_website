import axios from 'axios';
import { MAIN_URL } from '@/common/Url';
export function userLogin(data) {
    return axios.post(`${MAIN_URL}login`, data)
}
export function userRegister(data) {
    return axios.post(`${MAIN_URL}register`, data)
}
export function contact(data) {
    return axios.post(`${MAIN_URL}contact`, data)
}
export function banner() {
    return axios.get(`${MAIN_URL}banners`)
}
export function products() {
    return axios.get(`${MAIN_URL}products`)//main
} export function categories() {
    return axios.get(`${MAIN_URL}categories`)// sidebar
}
export function categoryProduct(id) {
    return axios.get(`${MAIN_URL}categories/${id}`)//home
}
export function productDetails(id) {
    return axios.get(`${MAIN_URL}products/${id}`);//productdetails
}
export function userDetails(id) {
    return axios.get(`${MAIN_URL}user/${id}`)
}
export function updateUser(id, data) {
    return axios.put(`${MAIN_URL}user/${id}`, data)
}
export function changePassword(id, data) {
    return axios.put(`${MAIN_URL}password/${id}`, data);
}
export function wishlist(data) {
    return axios.post(`${MAIN_URL}wishlist`, data);
}
export function getWishlist(id) {
    return axios.get(`${MAIN_URL}wishlist/${id}`);
}
export function deletewishlist(id) {
    return axios.delete(`${MAIN_URL}wishlist/${id}`);
}
export function coupon() {
    return axios.get(`${MAIN_URL}usercoupon`);
}
export default {
    userLogin, userRegister, contact, banner, products, categories, categoryProduct, productDetails,
    userDetails, updateUser, wishlist, getWishlist, deletewishlist,coupon
};