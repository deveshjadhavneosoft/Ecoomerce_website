import Vue from 'vue';
import VueSweetalert2 from 'vue-sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
Vue.use(VueSweetalert2);
import Router from 'vue-router';
Vue.use(Router);
import Main from '../components/Main.vue'
import Contact from '../components/Contact.vue';
import Login from '../components/Login.vue';
import Blogsingle from '../components/Blogsingle.vue'
import Blog from '../components/Blog.vue'
import Cart from '../components/Cart.vue'
import Error from '../components/Error.vue'
import Shop from '../components/Shop.vue'
import Productdetails from '../components/Productdetails.vue'
import Checkout from '../components/Checkout.vue'
import Home from '../components/Home.vue'
import Account from '../components/Account.vue'
import Wishlist from '../components/Wishlist.vue'
function myGuard(to, from, next) {
    let isAuthenticated = false;
    if (localStorage.getItem('uid') != undefined) {
        isAuthenticated = true;
    }
    else {
        isAuthenticated = false;
    }
    if (isAuthenticated) {
        next(); //allow to enter route
    }
    else {
        alert("You need to login first")
        next("/login");
    }
}
export default new Router({
    // mode: "history",
    routes: [
        {
            path: '/',
            name: 'Main',
            component: Main
        },
        {
            path: '/home/:id',
            name: 'Home',
            component: Home
        },
        {
            path: '/contact',
            name: 'Contact',
            component: Contact
        },
        {
            path: '/login',
            name: 'Login',
            component: Login
        },
        {
            path: '/blogsingle',
            name: 'Blogsingle',
            component: Blogsingle
        },
        {
            path: '/blog',
            name: 'Blog',
            component: Blog
        },
        {
            path: '/cart',
            name: 'Cart',
            component: Cart
        },
        {
            path: '/404',
            name: 'Error',
            component: Error
        },
        {
            path: '/shop',
            name: 'Shop',
            component: Shop
        },
        {
            path: '/productdetails/:id',
            name: 'Productdetails',
            component: Productdetails
        },
        {
            path: '/checkout',
            name: 'Checkout',
            beforeEnter: myGuard,
            component: Checkout
        },

        {
            path: '/account/:id',
            name: 'Account',
            beforeEnter: myGuard,
            component: Account
        },
        {
            path: '/wishlist',
            name: 'Wishlist',
            beforeEnter: myGuard,
            component: Wishlist
        },
    ]
})